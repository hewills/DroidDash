Thanks for playing my first Ludum Dare 53 game!

To play on Windows:

Run DroidDash.exe
or use winsetup.exe to setup your Display prior to running.
Recommend starting in Windowed Mode by using winsetup.exe.

All files need to be together in the same directory.

Controls:

Right-click to LOOK at objects.
Left-click to INTERACT with objects.

Credits:

Game By: Hana Wills (https://hanaindiana.itch.io/)
Art by: Eric Hill (https://hillendymion.itch.io/) 
and Marian Hill (https://ldjam.com/users/deadsquid/)

Game Engine: Adventure Game Studios
Thanks to SpeechCenter in the AGS Community for the voice module.
Thanks to Bit Forest for hosting our Game weekend!

///------------------------------------------------------------

TrueType font display uses ALFont by Javier Gonzalez and the Freetype project. Distributed under the terms of the FreeType project license.

OGG player is alogg by Javier Gonzalez, using the Ogg Vorbis decoder, which is available from http://www.xiph.org/ Copyright (c) 2002, Xiph.org Foundation

MP3 player is almp3, by Javier Gonzalez and the FreeAmp team. It uses the mpg123 MP3 decoder, and is distributed under the terms of the GNU Lesser General Public License version 2.1.

